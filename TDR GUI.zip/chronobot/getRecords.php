<?php

$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");

if($link){
	mysql_select_db("chronobot");
	$q =$_GET['q'];/* "select * from users";*/
	$result=mysql_query($q);
	$rows = array();
	
	/*echo "uid, rid, datetime, source, type, value\n";*/
	while($row=mysql_fetch_assoc($result))
	{
		echo $row["rid"].", ".$row["uid"].", ".$row["datetime"].", ".$row["source"].", ".$row["type"].", ".$row["value"].", ".$row["originator"]."\n";
		/*
		foreach($row as $key => $value) {
			echo "$value, ";
		}*/
	}
	echo "\n";
}
	
exit();  
?>