<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
</head>
<body>
<center>
	<form method="post" action="search.php">
		<input type="text" name="searchVal"/>
		<button type="submit" name="btnSearch">Search</button>
		<br>
		<br>
		<table rules="rows" border="1" cellpadding="3" cellspacing="1" style"width:90%;background-color:#FFFFE0;">
		<tr valign="top" style="background-color:#BDB76B;color:#ffffff;">
    		<td valign="top" align="center"> 
			<input type="checkbox" name="check_list[]" value="ID"><br/><label>ID</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="LastName"><br/><label>Last Name</label>	
		</td> 
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="FirstName"><br/><label>First Name</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="Email"><br/><label>Email</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="Date"><br/><label>Date</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="SPO2"><br/><label>SPO2</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="dtspo2"><br/><label>Date Time SPO2</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="Systolic"><br/><label>Systolic</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="Diastolic"><br/><label>Diastolic</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="Pulse"><br/><label>Pulse</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="bp"><br/><label>Blood Pressure</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="dtbp"><br/><label>Date Time Blood Pressure</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="ekg"><br/><label>EKG Data Stream</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="dtekg"><br/><label>Date Time EKG</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="temp"><br/><label>Temperature Data Stream</label>
		</td>
    		<td valign="top" align="center">
			<input type="checkbox" name="check_list[]" value="dttemp"><br/><label>Date Time Temperature</label>
		</td>
		</tr>
		</table>


	</form>
</center>
</body>