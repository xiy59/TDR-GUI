<?php
$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 
session_start();

//include_once("menu.php");

$type = $_SESSION['graphname'];
$email = $_SESSION['email'];
if (!$_SESSION['selectuser']){
	$selectuser = $email;
	$_SESSION['selectuser'] = $selectuser;
}
require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('jpgraph/jpgraph_mgraph.php');

$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND users.email = '$selectuser'";

if ($_SESSION['displaytime'] == 1) {
			 $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
	 }
	 else if ($_SESSION['displaytime'] == 2) {
		          $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	  }
	 else if ($_SESSION['displaytime'] == 3) {
			  $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
}
$result=mysql_query($q);
$rows = array();
while($row=mysql_fetch_assoc($result))
{
       // if (preg_match("/^\d*$/", $row["value"])) {
			if ($row["type"]=='fertilizer'){
			    //echo $row["type"]." ".$row["value"]."<br>";
				$datay[] = $row["value"];
				$time[] = substr($row["datetime"],0,10);
			}
			if ($row["type"]=='light'){
				$datay2[] = $row["value"];
				$time2[] = substr($row["datetime"],0,10);
			}
			if ($row["type"]=='moisture'){
				$datay3[] = $row["value"];
				$time3[] = substr($row["datetime"],0,10);
			}
			
			
				
       // }
}
// Setup the graph
$graph = new Graph(800,600);
$graph->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph->SetTheme($theme_class);
$graph->img->SetAntiAliasing(false);
$graph->title->Set("Fertilizer");
$graph->SetBox(false);

$graph->img->SetAntiAliasing();

$graph->yaxis->HideZeroLabel();
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

$graph->xgrid->Show();
$graph->xgrid->SetLineStyle("solid");
$graph->xaxis->SetTickLabels($time); // time array - x axis
$graph->xgrid->SetColor('#E3E3E3');

// Create the line
$p1 = new LinePlot($datay);
$graph->Add($p1);
$p1->SetColor("#6495ED");
$p1->SetLegend('Time');


$p1->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
$p1->mark->SetColor('#55bbdd');
$p1->mark->SetFillColor('#55bbdd');
$p1->SetCenter();
$graph->img->SetAntiAliasing(false); 
$p1->SetWeight(2); 


$graph->legend->SetFrameWeight(1);


// Setup the graph
$graph2 = new Graph(800,600);
$graph2->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph2->SetTheme($theme_class);
$graph2->img->SetAntiAliasing(false);
$graph2->title->Set("Light");
$graph2->SetBox(false);

$graph2->img->SetAntiAliasing();

$graph2->yaxis->HideZeroLabel();
$graph2->yaxis->HideLine(false);
$graph2->yaxis->HideTicks(false,false);

$graph2->xgrid->Show();
$graph2->xgrid->SetLineStyle("solid");
$graph2->xaxis->SetTickLabels($time2); // time array - x axis
$graph2->xgrid->SetColor('#E3E3E3');

// Create the line
$p2 = new LinePlot($datay2);
$graph2->Add($p2);
$p2->SetColor("#6495ED");
$p2->SetLegend('Time');


$p2->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
$p2->mark->SetColor('#55bbdd');
$p2->mark->SetFillColor('#55bbdd');
$p2->SetCenter();
$graph2->img->SetAntiAliasing(false); 
$p2->SetWeight(2); 


$graph2->legend->SetFrameWeight(1);


// Setup the graph
$graph3 = new Graph(800,600);
$graph3->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph3->SetTheme($theme_class);
$graph3->img->SetAntiAliasing(false);
$graph3->title->Set("Moisture");
$graph3->SetBox(false);

$graph3->img->SetAntiAliasing();

$graph3->yaxis->HideZeroLabel();
$graph3->yaxis->HideLine(false);
$graph3->yaxis->HideTicks(false,false);

$graph3->xgrid->Show();
$graph3->xgrid->SetLineStyle("solid");
$graph3->xaxis->SetTickLabels($time3); // time array - x axis
$graph3->xgrid->SetColor('#E3E3E3');

// Create the line
$p3 = new LinePlot($datay3);
$graph3->Add($p3);
$p3->SetColor("#6495ED");
$p3->SetLegend('Time');


$p3->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
$p3->mark->SetColor('#55bbdd');
$p3->mark->SetFillColor('#55bbdd');
$p3->SetCenter();
$graph3->img->SetAntiAliasing(false); 
$p3->SetWeight(2); 


$graph3->legend->SetFrameWeight(1);




// Output line
//$graph->Stroke();

$mgraph = new MGraph();
$mgraph->Add($graph);
$mgraph->Add($graph2,0,600);
$mgraph->Add($graph3,0,1200);

$mgraph->Stroke();
?>