<?php
include_once("conn_db.php");
include_once("menu.php");
$type = $_GET["type"];
if ($type == 'follow'){
    $type = $_SESSION['recordtype']; 
}
$email = $_SESSION['email'];
$_SESSION['recordtype'] = $type;
if (!$_SESSION['selectuser']){
	$selectuser = $email;
	$_SESSION['selectuser'] = $selectuser;
}
?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Detail List <small>Statistics Details</small>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> <?php echo "Detail list for e-mail: ".$_SESSION['selectuser'];?>
			</li>
		</ol>
	</div>
</div>

<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Record ID</th><th>Uid</th><th>Date</th><th>Source</th><th>Type</th><th>Reading</th><th>Originator</th>
	</tr>
	<?php
	if ($type == 'Ren'){
		$q = "select * from records, users where users.uid = records.uid AND (records.source = 'Analysis' OR records.source = 'EKG' OR records.source = 'SPO2' OR records.source = 'BloodPressure' OR records.source = 'temperature') AND users.email = '$selectuser'";
	}
       if ($type == 'EKG'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'EKG' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'EKG';
	}
       if ($type == 'spo2'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'SPO2' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'SPO2';
	}
        if ($type == 'systolic'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'BloodPressure' AND records.type = 'systolic' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'BloodPressure';
	}
        if ($type == 'diastolic'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'BloodPressure' AND records.type = 'diastolic' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'BloodPressure';
	}
         if ($type == 'pulse'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'BloodPressure' AND records.type = 'pulse' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'BloodPressure';
	}
         if ($type == 'temp'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Temperature' AND records.type = 'temp' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Temperature';
	}
        if ($type == 'Tian'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Parrot';
	}
        if ($type == 'Di'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Temperature' AND records.type = 'temp' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Temperature';
	}
        if ($type == 'fertilizer'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND records.type = 'fertilizer' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Parrot';
	}
         if ($type == 'moisture'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND records.type = 'moisture' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Parrot';
	}
         if ($type == 'light'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND records.type = 'light' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Parrot';
	}
	 if ($_SESSION['displaytime'] == 1) {
			 $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
	 }
	 else if ($_SESSION['displaytime'] == 2) {
		          $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	  }
	 else if ($_SESSION['displaytime'] == 3) {
			  $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
        }
        $q = $q. "order by datetime desc";
        //echo $q;
	$result=mysql_query($q);
	$rows = array();
	while($row=mysql_fetch_assoc($result))
	{
		echo"<tr><th>".$row["rid"]."</th><th>".$row["uid"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th><th>".$row["originator"]."</th>";
	}
	?>
</table>

<table class="table table-bordered table-hover table-striped">
	<tr>
	<td><a href="source_notChi.php?type=<?php echo $type;?>"><input type="submit" value="View Details" /></a>
	</td>
	<td><a href="http://ksiresearchorg.ipage.com/chronobot/draw_graph_notChi.php?type=<?php echo $type;?>"><input type="submit" value="Draw Graphs" /></a>
	</td>
	<td><a href="http://ksiresearchorg.ipage.com/chronobot/enter_data_notChi.php"><input type="submit" value="Enter Data" /></a>
	</td>
	</tr>
</table>
	

		
<?php
include_once("bottom.php");
?>