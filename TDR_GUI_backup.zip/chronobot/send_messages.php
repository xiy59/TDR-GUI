<?php
$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");
if($link){
	$msg = $_GET['msg'];
	$uid = $_GET['uid'];
	echo "Message sent!";
	mysql_select_db("chronobot");
	$sql = "INSERT INTO  `messages` (  `mid` ,  `uid` ,  `read` ,  `message` ) VALUES ( NULL,'$uid','0',\"$msg\");";
	$result=mysql_query($sql);
}
exit();  
?>