<?php
include_once("conn_db.php");
include_once("menu.php");
$type = $_GET["type"];
if ($type == 'follow'){
    $type = $_SESSION['recordtype']; 
}
$email = $_SESSION['email'];

$loginuid = $_SESSION['loginuid'];
$selectuser_uid = $_SESSION['selectuser_uid'];

$M5 = "<Msg><Item><Key>Scope</Key><Value>SIS.Chi</Value></Item><Item><Key>MessageType</Key><Value>Alert</Value></Item><Item><Key>Sender</Key><Value>GUI</Value></Item><Item><Key>Receiver</Key><Value>ChiMonitor</Value></Item><Item><Key>Purpose</Key><Value>AnalyzeData</Value></Item><Item><Key>Uid</Key><Value>376896</Value></Item></Msg>";

$M5tongue = -1;
$M5fatigue = -1;
$M5weakBreadth = -1;
$M5pulse = -1;
$M5sweaty = -1;

$q1 = "select * from records, users where (records.source = '$type' or records.source = 'SocialNetwork') and users.uid = records.uid and users.email = '$selectuser' and records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
$result=mysql_query($q1);
$rows = array();
while($row=mysql_fetch_assoc($result))
	{
		if ($row["type"]=='tongue'){
			//echo $row["type"]." ".$row["value"]."<br>";
			$M5tongue = $row["value"];
		}
		if ($row["type"]=='fatigue'){
			$M5fatigue = $row["value"];
		}
		if ($row["type"]=='weakBreadth'){
			$M5weakBreadth = $row["value"];
		}
		if ($row["type"]=='pulse'){
			$M5pulse = $row["value"];
		}
		if ($row["type"]=='sweaty'){
			$M5sweaty = $row["value"];
		}
		if ($row["type"]=='chiTotal'){
			$M5chiTotal = $row["value"];
		}
	}




?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Detail List <small><?php echo " for e-mail: ".$_SESSION['selectuser'];?></small>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> Analyze Data
			</li>
		</ol>
	</div>
</div>

<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Record ID</th><th>Email</th><th>Date</th><th>Source</th><th>Type</th><th>Reading</th>
	</tr>
	<?php
	$q = "select * from records, users where records.source = 'Analysis' and records.type = 'ChiTotal' and users.uid = records.uid and users.email = '$selectuser' and records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW() order by datetime desc";
        //echo $q;
	$result=mysql_query($q);
	$rows = array();
	$findchi = 0;
	while($row=mysql_fetch_assoc($result))
	{
		echo"<tr><th>".$row["rid"]."</th><th>".$row["email"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th>";
                
		$findchi = 1;
                break;
	}
	 if ($findchi == 0){
		$sql = "INSERT INTO messages (uid,readid,message,messagetype,tongue,fatigue,weakBreadth,pulse,sweaty,chiTotal,originator) VALUES ('$selectuser_uid','0','$M5','M5','$M5tongue','$M5fatigue','$M5weakBreadth','$M5pulse','$M5sweaty','$M5chiTotal','$loginuid')";
		$result = mysql_query($sql);
       
                echo "No Chi result found, please access later";
	}
	?>
</table>


<table class="table table-bordered table-hover table-striped">
	<tr>
	<td><a href="source.php?type=follow"><input type="submit" value="View Details" /></a>
	</td>
	<td><a href="http://ksiresearchorg.ipage.com/chronobot/analysis_data.php?type=<?php echo $type;?>"><input type="submit" value="Draw Graphs" /></a>
	</td>
	<td><a href="analyzeChidata.php?type=follow"><input type="submit" value="Analyze Data" /></a>
	</td>
	<td><a href="findsimilar.php?type=follow"><input type="submit" value="Find Similar" /></a>
	</td>
	<td><a href="http://ksiresearchorg.ipage.com/chronobot/enter_data.php"><input type="submit" value="Enter Data" /></a>
	</td>
	</tr>
</table>

<?php
include_once("bottom.php");
?>