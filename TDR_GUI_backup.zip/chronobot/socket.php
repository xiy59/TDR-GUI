<?php

$addr = gethostbyname("www.example.com");
$port = "53217";

$client = stream_socket_client("tcp://$addr:$port", $errno, $errorMessage);

if ($client === false) {
    throw new UnexpectedValueException("Failed to connect: $errorMessage");
}

fwrite($client, "GET / HTTP/1.0\r\nHost: www.example.com\r\nAccept: */*\r\n\r\n");
echo "<h1>".stream_get_contents($client)."</h1>";
fclose($client);

?>