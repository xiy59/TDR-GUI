<?php
	if(isset($_POST['login'])){
		include_once('conn_db.php');

		$add_user_name = $_POST['add_user_name'];
		$add_user_password = $_POST['add_user_password'];
		$add_user_uid = $_POST['add_user_uid'];
		$add_user_ip = $_POST['add_user_ip'];
                $add_user_first_name = $_POST['add_user_first_name'];
                $add_user_last_name = $_POST['add_user_last_name'];
		$add_user_gender = $_POST['add_user_gender'];
		$add_user_dob = $_POST['add_user_dob'];
		$add_user_isSocialNetworkMember = $_POST['add_user_isSocialNetworkMember'];
		$add_user_weight = $_POST['add_user_weight'];   

		$sql = "INSERT INTO users VALUES ('$add_user_uid','$add_user_ip','$add_user_password','$add_user_name','$add_user_first_name','$add_user_last_name',0,'$add_user_gender','$add_user_dob','$add_user_isSocialNetworkMember','$add_user_weight')";
                
		$result = mysql_query($sql);

                //$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
		
		
		echo "Add Succeed!!!";
		echo "<script>window.location = 'dashboard.php';</script>";
		//echo $_SESSION['query'];
	}
        if(isset($_POST['cancel'])){
                echo "<script>window.location = 'dashboard.php';</script>";
        }
?>