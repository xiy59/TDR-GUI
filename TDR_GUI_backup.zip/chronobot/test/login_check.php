<?php
	//if(isset($_POST['login'])){
		include_once('conn_db.php');
		$email = $_POST['email'];
		$password = $_POST['password'];
		$option = $_POST['option'];
		
		$query = "SELECT * FROM records, users WHERE users.uid = records.uid";
		
		if ($option == 1) {
			$_SESSION['query'] =  $query . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
		}
		else if ($option == 2) {
			$_SESSION['query'] =  $query . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
		}
		else if ($option == 3) {
			$_SESSION['query'] =  $query . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
		}
		else if ($option == 4) {
			$_SESSION['query'] = $query;
		}
		if($email != null){
			$_SESSION['email'] = $email;
			$_SESSION['query'] = $_SESSION['query'] . " and users.email = '$email'";
		}
		
		//select from users check username & password & set session[superuser]
		$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
		$result = mysql_query($sql);
		$row=mysql_fetch_assoc($result);
		$count=mysql_num_rows($result);
		
		if ($count == 1) {
			$_SESSION['isSuperUser'] = $row['isSuperUser'];
			echo "<script>window.location = 'dashboard.php';</script>";
		}
		else {
			echo "Login Failed!!!";
		}
		//echo $_SESSION['query'];
	//}
?>