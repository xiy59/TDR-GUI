<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administration</title>
</head>

<body>
<center><table style="border:solid;">
<caption><b>Statistics:</b></caption>
<br>
<tr><th>Id</th><th>Last Name</th><th>First Name</th><th>E-mail</th><th>Date</th><th>SPO2</th><th>Systolic</th><th>Diastolic</th><th>Pulse</th></tr>
<?php
include_once("conn_db.php");

$q="select * from users";
$result=mysql_query($q);
while($row=mysql_fetch_assoc($result))
{
 echo"<tr><th>".$row["id"]."</th><th>".$row["last_name"]."</th><th>".$row["first_name"]."</th><th>".$row["e-mail"]."</th><th>".$row["date"]."</th><th>".$row["SPO2"]."</th><th>".$row["Systolic"]."</th><th>".$row["Diastolic"]."</th><th>".$row["Pulse"]."</th></tr>";
 }
?>
</table>

<a href=".html"></a>

</center>
</body>
</html>