<?php
include_once("conn_db.php");
include_once("menu.php");
$type = $_GET["type"];
$email = $_SESSION['email'];
?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Enter Data <small><?php echo " for e-mail: ".$_SESSION['selectuser'];?></small>
		</h1>
                <ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> Enter Data
			</li>
		</ol>
	</div>
</div>

<div class="panel-body">
	<form role="form" method="post" action="enter_data_check.php">
		<div class="form-group">
			<label for="enter_source">Source: SocialNetwork</label>
		</div>
		
        <div class="form-group">
			<label for="tongue_reading">Type: tongue</label>
			<input type="text" class="form-control" id="tongue_reading" name="tongue_reading">
		</div>
		
        <div class="form-group">
			<label for="fatigue_reading">Type: fatigue</label>
			<input type="text" class="form-control" id="fatigue_reading" name="fatigue_reading">
		</div>
		
        <div class="form-group">
			<label for="weakBreadth_reading">Type: weakBreadth</label>
			<input type="text" class="form-control" id="weakBreadth_reading" name="weakBreadth_reading">
		</div>
		
        <div class="form-group">
			<label for="pulse_reading">Type: pulse</label>
			<input type="text" class="form-control" id="pulse_reading" name="pulse_reading">
		</div>
		
        <div class="form-group">
			<label for="sweaty_reading">Type: sweaty</label>
			<input type="text" class="form-control" id="sweaty_reading" name="sweaty_reading">
		</div>
		
        <div class="form-group">
			<label for="chiTotal_reading">Type: chiTotal</label>
			<input type="text" class="form-control" id="chiTotal_reading" name="chiTotal_reading">
		</div>
				<button name="submit" type="submit" class="btn btn-default">Submit</button>
                <button name="cancel" type="submit" class="btn btn-default">Cancel</button>
	</form>
</div>


<?php
include_once("bottom.php");
?>