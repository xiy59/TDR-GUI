<?php
	
		include_once('conn_db.php');
      

        if(isset($_POST['submit'])){ 
			//$enter_source = 'SocialNetwork';
			//$enter_type = 'tongue';
                        
			
			$tongue_reading = $_POST['tongue_reading'];
			$fatigue_reading = $_POST['fatigue_reading'];
			$weakBreadth_reading = $_POST['weakBreadth_reading'];
			$pulse_reading = $_POST['pulse_reading'];
			$sweaty_reading = $_POST['sweaty_reading'];
			$chiTotal_reading = $_POST['chiTotal_reading'];
			$enter_uid = $_SESSION['loginuid'];
                        $selectuser_uid = $_SESSION['selectuser_uid'];
			
                        
			$t=time();
			if ($tongue_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'SocialNetwork','tongue','$tongue_reading','$enter_uid')";
				$result = mysql_query($sql);
			}
			if ($fatigue_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'SocialNetwork','fatigue','$fatigue_reading','$enter_uid')";
				$result = mysql_query($sql);
			}
			if ($weakBreadth_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'SocialNetwork','weakBreadth','$weakBreadth_reading','$enter_uid')";
				$result = mysql_query($sql);
			}
			if ($pulse_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'SocialNetwork','pulse','$pulse_reading','$enter_uid')";
				$result = mysql_query($sql);
			}
			if ($sweaty_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'SocialNetwork','sweaty','$sweaty_reading','$enter_uid')";
				$result = mysql_query($sql);
			}
			if ($chiTotal_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'SocialNetwork','chiTotal','$chiTotal_reading','$enter_uid')";
				$result = mysql_query($sql);
			}
		

                        if (!$_POST['tongue_reading']) $tongue_reading = -1;
                        if (!$_POST['fatigue_reading']) $fatigue_reading = -1;
                        if (!$_POST['weakBreadth_reading']) $weakBreadth_reading = -1;
                        if (!$_POST['pulse_reading']) $pulse_reading = -1;
                        if (!$_POST['sweaty_reading']) $sweaty_reading = -1;

                        $M10 = "<Msg><Item><Key>Scope</Key><Value>SIS.Chi</Value></Item><Item><Key>MessageType</Key><Value>Alert</Value></Item><Item><Key>Sender</Key><Value>SocialNetMonitor</Value></Item><Item><Key>Receiver</Key><Value>SocialNetAdvertiser</Value></Item><Item><Key>Purpose</Key><Value>Modelling</Value></Item><Item><Key>Uid</Key><Value>1</Value></Item></Msg>";




                        $sql = "INSERT INTO messages(uid,message,messagetype,tongue,fatigue,weakBreadth,pulse,sweaty,chiTotal,originator) VALUES ('$selectuser_uid','$M10','M10','$tongue_reading','$fatigue_reading','$weakBreadth_reading','$pulse_reading','$sweaty_reading','$chiTotal_reading','$enter_uid')";
			$result = mysql_query($sql);

			echo "Enter Succeed!!!";
            echo "<script>window.location = 'source.php?type=follow';</script>";
		//echo "<script>window.location = 'dashboard.php';</script>";
		//echo $_SESSION['query'];
        }
        else if(isset($_POST['cancel'])) {
            echo "<script>window.location = 'source.php?type=follow';</script>";
        }
	//}
?>